#version 330
#extension GL_ARB_separate_shader_objects : require

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#include <minecraft:fog.glsl>
#include <minecraft:sample_lightmap.glsl>
#endif

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
layout(location = 3) in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
#endif

layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;

void main() {
#ifdef IS_GUI
    // KitPvP radar HUD: the invisible boss bar's #FEFEFE title moves from top centre to the
    // top-left corner (89 wide, 4 px in from the left edge, top at y = 4)
    bool radarHud = all(lessThan(abs(Color.rgb * 255.0 - vec3(254.0)), vec3(0.6)));
    vec3 pos = Position;
    if (radarHud) {
        float guiW = 2.0 / ProjMat[0][0];
        // the title starts at floor(guiW / 2) - 44; move it to the top-left corner, 4 px in
        float w = floor(guiW + 0.5);
        pos = Position + vec3(4.0 - (floor(w / 2.0) - 44.0), -15.0, 0.0);
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
#else
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
#ifdef IS_GUI
    if (radarHud) vertexColor = vec4(1.0);
#endif
    texCoord0 = UV0;
}
